import * as React from 'react';
import { render } from 'react-dom';
import App from './App';
import './scss/app';

render(<App />, document.getElementById("root"));